## Author:  Kate Lofgren (klofgren@g.harvard.edu)
## Date:    8/13/2018
## Purpose: Calculate deaths and CHE averted for upstream interventions with downstream interventions

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(gdata)

## set seed
  set.seed(02139)

## set directory
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")

## bring in income draws
  hh.incomes <- read.table("./03_output_data/income_draws.csv",sep=",",header=T)
  names(hh.incomes) <- "hh.incomes"

## bring in input parameter master file
  ## bring in temporal spacing to map intervention information
  print("USING FILE:")
  print(file)
  
  map <- read.xls(file,sheet="Temporal Spacing",stringsAsFactors=F)
  names(map)[1] <- "gbd_n"
  
  ## for this, keep int=1 with int 2's
  map <- map[,c("gbd_n","int_1_n","int_2_n")]
  map <- map[!is.na(map$int_2_n),]
  
  ## create a list of all the interventions we should have at end of code for error checking
  check <- unique(map$int_1_n)
  check[which(check==3.2)] <- 3
  
  ## bring in input parameter master file
  data <- read.csv("./01_input_data/02_final_input_parameters.csv",header=T,stringsAsFactors=F)
  
  ## change data variables for downstream interventions
  data.down <- data[,c("int_n","int_target","int_eff_target",
                       "target_n","target_n_LB","target_n_UB",
                       "population","baseline_cov",
                       "int_eff","int_eff_LB","int_eff_UB",
                       "gbd_n","burden_amenable",
                       "unit.cost","oop.cost","time_lag","screen","p.treat","uc.screen","uc.treat")]
  names(data.down) <- c("int_2_n","int_2_target","int_2_eff_target",
                        "int_2_target_n","int_2_target_n_LB","int_2_target_n_UB",
                        "int_2_population","int_2_baseline_cov",
                        "int_2_eff","int_2_eff_LB","int_2_eff_UB",
                        "gbd_n","int_2_burden_amenable",
                        "int_2_unit.cost","int_2_oop.cost","int_2_time_lag")
  
## merge intervention info onto mapping file
  data <- merge(map,data,by.x=c("gbd_n","int_1_n"),by.y=c("gbd_n","int_n"),all.x=T)
  data <- merge(data,data.down,by=c("gbd_n","int_2_n"),all.x=T)
  
# create a variable for OOP cost as a percent
  data$oop.cost.per <- data$oop.cost
  data$oop.cost <- NA 
  data$int_2_oop.cost.per <- data$int_2_oop.cost
  data$int_2_oop.cost <- NA
  
# keep a master file to pull variables from
  master <- data

############################################
## Loop over average, LB and UB scenarios ##
############################################
ticker <- 0
  
for(e in c("MEAN","LB","UB")) {
  if(e=="MEAN") {
    int_eff <- master$int_eff
  } else if(e=="LB") {
    int_eff <- master$int_eff_LB
  } else {
    int_eff <- master$int_eff_UB
  }
  
  for(s in c("MEAN","LB","UB")) {
    ## assign the right varaibles - set up
    if(s=="MEAN") {
      ## average
      target_n <- master$target_n
      incidence <- master$incidence
      CFR <- master$CFR
      deaths <- master$deaths
    } else if(s=="LB") {
      # LB
      target_n <- master$target_n_LB
      incidence <- master$incidence_LB
      CFR <- master$CFR_LB
      deaths <- master$deaths_LB
    } else {
      # UB
      target_n <- master$target_n_UB
      incidence <- master$incidence_UB
      CFR <- master$CFR_UB
      deaths <- master$deaths_UB
    }
    
    ticker <- ticker + 1
    ## calculate the newly treated population
        data$new_tx_pop <- NA
        ## 1 - when intervention target is incidence or prevalence -- include burden addressable variable
        data$new_tx_pop[data$int_target != "population"] <- cov.delta *
          target_n[data$int_target != "population"] *
          data$burden_amenable[data$int_target != "population"] 
        ## 2 - when intervention target is population -- goes to everyone -- don't want addressable %
        data$new_tx_pop[data$int_target == "population"] <- cov.delta *
          target_n[data$int_target == "population"] 
    
    ## calculate the population previously seeking care -- that are now covered (i.e. the baseline coverage pop)
        data$baseline_coverage_pop <- NA
        ## 1 - when intervention target is incidence or prevalence -- include burden addressable variable
        data$baseline_coverage_pop[data$int_target != "population"] <- data$baseline_cov[data$int_target != "population"]  *
                                                                        target_n[data$int_target != "population"] *
                                                                        data$burden_amenable[data$int_target != "population"] 
        
        ## 2 - when intervention target is population -- goes to everyone -- don't want addressable %
        data$baseline_coverage_pop[data$int_target == "population"] <- data$baseline_cov[data$int_target == "population"]  *
                                                                        target_n[data$int_target == "population"] 
        
    ## calculate the total cost of scaling up coverage
    ## whole unit cost for newly covered, just OOP for baseline coverage
    data$total_cost <- (data$new_tx_pop*data$unit.cost) + (data$baseline_coverage_pop*data$oop.cost.per*data$unit.cost)
    
    ## covert OOP to dollars instead of %
    data$oop.cost <- data$oop.cost.per*data$unit.cost
    data$int_2_oop.cost <- data$int_2_oop.cost.per*data$int_2_unit.cost
    
    ## covert OOP for screen/treat costs to dollars instead of %
    data$oop.cost.screen <- data$oop.cost.per*data$uc.screen
    data$oop.cost.treat <- data$oop.cost.per*(data$uc.treat + data$uc.screen) # both treated and screened
    
    #################################
    ## Deaths averted per $ spent  ##
    ################################# 
    ## deaths averted just for newly covered population
    ## Calculations for when efficacy estimate is for INCIDENCE
    data$delta.incidence <- NA
    i <- which(data$int_eff_target=="incidence")
    data$delta.incidence[i] <- cov.delta*int_eff[i]*data$burden_amenable[i]*incidence[i]
    
    ## for changes in incidence, now calculate delta deaths based on change in case fatality ratio
    data$delta.deaths <- NA
    data$delta.deaths[i] <- CFR[i]*data$delta.incidence[i]
    
    ## Calculations for when efficacy estimate is for MORTALITY
    m <- which(data$int_eff_target=="mortality")
    data$delta.deaths[m] <-   cov.delta*
                              int_eff[m]*
                              data$burden_amenable[m]*
                              deaths[m]
    
    
    ## calculate the change in incidence using change in mortality
    data$new.incidence <- NA
    data$new.incidence[m] <- (deaths[m]-data$delta.deaths[m])/CFR[m]
    data$delta.incidence[m] <- incidence[m] - data$new.incidence[m]
    
    #############################
    ## CHE averted per $ spent ##
    #############################
    # CHE averted for both newly and baseline covered populations
    ## adjust the changes in incidence to the amenable percent of disease and intervention coverage
    ## for a downstream intervention (int_2, any change is dependent on the % of that incidence amenable and baseline coverage)
    data$int_2_delta.incidence <- data$delta.incidence*data$int_2_burden_amenable*data$int_2_baseline_cov 
    
    ## calculate the direct FRP from changes in the OOP expenditures of preventative care
    ## loop by row
    for(r in 1:dim(data)[1]) {
      ## two calcs for screen/treat interventions
      if(data$screen[r] == 1) {
          ## need to consider exposure to both screen or treat
          ## draw subset of incomes
          ## all target population
          #i <- runif(n=round(cov.delta*target_n[r]),min=1,max=total.draws) ## changing on 11/7 to include amenable %
          i.screen <- runif(n=round((data$new_tx_pop[r] + data$baseline_coverage_pop[r])*(1-data$p.treat[r])),min=1,max=total.draws)
          i.treat <- runif(n=round((data$new_tx_pop[r] + data$baseline_coverage_pop[r])*(data$p.treat[r])),min=1,max=total.draws)
          tx.incomes.screen <- hh.incomes[i.screen,]
          tx.incomes.treat <- hh.incomes[i.treat,]
          
          ## calculate the percent of income OOP represents
          i.per.screen <- data$oop.cost.screen[r]/tx.incomes.screen
          i.per.treat <- data$oop.cost.treat[r]/tx.incomes.treat
          
          ## generate counts of CHE averted at all cutoffs
          che.counts <- vector()
          
          index <- 0
          for(c in cutoffs) {
            index <- index + 1
            che.counts[index] <- length(which(i.per.screen >= c)) + length(which(i.per.treat >= c))
          }
          data$che.10.direct[r] <- che.counts[1]
          data$che.25.direct[r] <- che.counts[2]
      } else {
        ## draw subset of incomes
        ## all target population
        #i <- runif(n=round(cov.delta*target_n[r]),min=1,max=total.draws) ## changing on 11/7 to include amenable %
        i <- runif(n=round(data$new_tx_pop[r] + data$baseline_coverage_pop[r]),min=1,max=total.draws)
        tx.incomes <- hh.incomes[i,]
        
        ## calculate the percent of income OOP represents
        i.per <- data$oop.cost[r]/tx.incomes
        
        ## generate counts of CHE averted at all cutoffs
        che.counts <- vector()
        index <- 0
        for(c in cutoffs) {
          index <- index + 1
          che.counts[index] <- length(which(i.per >= c))
          
        }
        data$che.10.direct[r] <- che.counts[1]
        data$che.25.direct[r] <- che.counts[2]
      } # closes the if/else loop
    }  # closes row loop
    
    ## calculate FRP from downstream OOP expenditures averted
    ## loop by row
    for(r in 1:dim(data)[1]) {
      ## draw subset of incomes
      i.1 <- runif(n=round(data$int_2_delta.incidence[r]),min=1,max=total.draws)
      tx1.incomes <- hh.incomes[i.1,]
      
      ## calculate the percent of income OOP represents
      i.per.1 <- data$int_2_oop.cost[r]/tx1.incomes
      
      ## generate counts of CHE averted at all cutoffs
      che.counts.1 <- vector()
      index <- 0
      for(c in cutoffs) {
        index <- index + 1
        che.counts.1[index] <- length(which(i.per.1 >= c))
      } # cutoff loop
      data$che.10.indirect[r]    <- che.counts.1[1] 
      data$che.25.indirect[r]    <- che.counts.1[2] 
    }  # closes row loop
    
    # combine CHE metrics for indirect and direct, estimate FRP and 
    data$che.10    <-   data$che.10.direct + data$che.10.indirect
    data$che.25    <-   data$che.10.direct + data$che.10.indirect
    
    ## generate time-lag discounted versions
    data$t <- NA
    data$t[data$time_lag=="Immediate"] <- 0
    data$t[data$time_lag=="5 years"] <- 5
    data$t[data$time_lag=="10 years"] <- 10
    data$t[data$time_lag=="20 years"] <- 20
    data$delta.deaths.npv <- data$delta.deaths/(1.03^data$t)
    ## only want to discount indirect CHE since direct CHE will occur NOW
    data$che.10.npv <- data$che.10.direct + data$che.10.indirect/(1.03^data$t)
    data$che.25.npv <- data$che.25.direct + data$che.25.indirect/(1.03^data$t)
    
    # add variables to track what uncertainty scenarios are being used
    data$int_eff_uncert <- e
    data$pop_burden_uncert <- s
    
    ## save file with all vars
    if(ticker==1) {
      save <- data
    } else {
      save <- rbind(save,data)
    }
  } # closes pop/burden uncertainty loop 
} # closes int eff uncertainty loop
  
## save file with all vars
  write.table(save,paste0("./03_output_data/03_LINKED_all_vars.csv"),sep=",",row.names=F)

###### aggregate the results for each file ##########
ticker2 <- 0
  
for(e in c("MEAN","LB","UB")) {
  for(s in c("MEAN","LB","UB")) {
    ticker2 <- ticker2 + 1
    
    ## keep just the relevant data for a specific scenario
    data <- save[save$int_eff_uncert==e & save$pop_burden_uncert==s,]
    
    ## rename int_1_n to int_n
    names(data)[names(data)=="int_1_n"] <- "int_n"
    
    ## collapse the dataset so that each intervention is one row
    ## for maternal -- want just overall cost of SBA, BEmOC, CEmOC with added deaths etc. from 3.1-3.3 and 4.1-4.2
    mat <- data[data$int_n %in% c(3.1,3.2,3.3,4.1,4.2),]
    mat$int_n[mat$int_n %in% c(3.1,3.2,3.3)] <- 3
    mat$int_n[mat$int_n %in% c(4.1,4.2)] <- 4
    i.3.4 <- aggregate(cbind(delta.deaths,delta.deaths.npv,
                             che.10,che.10.npv,
                             che.10.direct,
                             che.25,che.25.npv,
                             che.25.direct) ~ int_n, FUN=sum, data=mat)
    
    ## only one intervention -- isolate to merge back in -- make cost = 0
    i.3.4$total_cost <- 0
    i.3.4$int_des <- "Basic emergency obstetric care"
    
    ## save master data for interventions 3 and 4
    i.mat <- i.3.4[i.3.4$int_n %in% c(3,4),c("int_n","int_des","delta.deaths","delta.deaths.npv",
                                             "total_cost",
                                             "che.10","che.10.npv",
                                             "che.10.direct",
                                             "che.25","che.25.npv",
                                             "che.25.direct")]
    
    ## for population targets -- just want overall cost (don't double count) + additive delta.deaths + che across disease categories
    i.population <- aggregate(cbind(delta.deaths,delta.deaths.npv,
                                    che.10,che.10.npv,
                                    che.10.direct,
                                    che.25,che.25.npv,
                                    che.25.direct) ~ int_n + int_des, 
                              FUN=sum,data[data$int_target=="population",], na.rm=T)
    i.pop.cost <- unique(data[data$int_target=="population",c("int_n","total_cost")]) # bring in total cost so it's counted once
    i.population <- merge(i.population,i.pop.cost,by=c("int_n"),all.x=T)
    
    ## put files together
    data <- rbind(i.mat,i.population)
    data <- data[order(data$int_n),]
    
    # check to make sure all the interventions are accounted for
    check == data$int_n
    
    ## add variables to track uncertainty scenario
    data$int_eff_uncert <- e
    data$pop_burden_uncert <- s
    
    ## save file with all vars
    if(ticker2==1) {
      save2 <- data
    } else {
      save2 <- rbind(save2,data)
    }

  } # closes the aggregation loop
} # closes the loop on pop/burden uncertainty loop
  
## save file with deaths and che estimates
  write.table(save2,paste0("./03_output_data/03_LINKED_deaths_che.csv"),sep=",",row.names=F)

  
  


 