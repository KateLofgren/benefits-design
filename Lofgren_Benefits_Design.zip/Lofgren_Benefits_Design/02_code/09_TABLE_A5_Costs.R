## Author:  Kate Lofgren
## Date:    8/3/2019
## Purpose: Appendix Table: Unit and OOP Cost

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(lpSolve)
  library(reshape2)
  library(viridis)
  library(gdata)

## set seed
  set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")
  
## unit costs
  u.cost <- read.xls(file,sheet="Interventions - Unit Cost",stringsAsFactors=F)
  u.cost <- u.cost[,c("Intervention..","Intervention.Unit.Cost..2016.USD.","Source","Details")]
  names(u.cost)[1:2] <- c("int_n","unit.cost")
  
## oop costs
  oop.cost <- read.xls(file,sheet="Interventions - OOP Costs",stringsAsFactors=F)
  oop.cost <- oop.cost[,c("Intervention..","OOP.HH.expenditure..","Source","Details")]
  names(oop.cost) <- c("int_n","oop.cost")
  
## merge together
  data <- merge(u.cost,oop.cost,by=c("int_n"))
  
## calculate the oop $ amount
  data$oop <- data$unit.cost*data$oop.cost
  data$oop.cost <- data$oop.cost*100
  data$oop <- round(data$oop,2)
  data$oop.cost <- round(data$oop.cost,2)
  data$unit.cost <- round(data$unit.cost,2)

# merge in intervention names
  temp <- read.xls(file,sheet="Interventions - Basics")
  temp$X <- NULL
  names(temp) <- c("WHO","int_n","int_des","int_des_short","int_target")
  temp <- temp[,c("int_n","int_des")]
  data <- merge(temp,data,by=c("int_n"),all.y=T)
  
## reorder and merge source and detail variables
  data$Sources <- paste0(data$Source,"; ",data$'NA')
  data$Details <- paste0(data$Details,"; ",data$'NA.1')
  data$Source <- data$'NA' <- data$'NA.1' <-  NULL
  data <- data[,c("int_n","int_des","unit.cost","oop.cost","oop","Sources","Details")]
  
## create better names for appendix table
  names(data)[1:5] <- c("Intervention #",
                         "Intervention",
                         "Unit Cost (2016 USD)",
                         "OOP Share (%)",
                         "OOP Cost (2016 USD)")
  
## outsheet to table to csv
  write.table(data,"./05_tables/TABLE_APPENDIX_5_Costs.csv",sep=",",row.names=F)
  
  
  