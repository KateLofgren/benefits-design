## Author:  Kate Lofgren (kate.lofgren@g.harvard.edu)
## Date:    9/15/2018
## Purpose: Graph results

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(ggplot2)
  library(gridExtra)
  library(gdata)
  library(ggExtra)
  library(viridis)
  library(RColorBrewer)
  library(forcats)

## set seed
  set.seed(02139)
  options(scipen = 999)
  
## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")
  
## bring in intervention names
  info <- read.xls(file,sheet="Interventions - Basics")
  info$X <- NULL
  names(info) <- c("WHO","int_n","int_des","int_des_short","int_target")
  info <- info[info$int_n!=3.1 & info$int_n!=3.2 & info$int_n!=3.3 & 
                 info$int_n!=4.1 & info$int_n!=4.2,] # don't want maternal care signal functions
  
##########################################################
## graph of total cost + deaths averted + che.10 averted -- black dots
# plot
  temp <- read.table("./03_output_data/04_combined_decision_vars.csv",sep=",",header=T,stringsAsFactors=F)
  temp <- temp[,c("int_des","delta.deaths","delta.deaths.LB","delta.deaths.UB",
                  "total_cost","che.10","che.10.LB","che.10.UB","int_eff_uncert","pop_burden_uncert")]
  temp <- unique(temp)
  
  ## merge with short int_des names
  temp <- merge(temp,info,by=c("int_des"),all.x=T)
  
  ## sort by cost
  temp <- temp[order(-temp$delta.deaths),]
  
  ## add ICER
  temp$ICER <- temp$total_cost/temp$delta.deaths
  
  ## add ICER category
  temp$ice.col <- NA
  cols <- brewer.pal(10,"Spectral")
  temp$ice.col[temp$ICER<1000] <- "1,000 or below"
  temp$ice.col[temp$ICER>=1000 & temp$ICER<10000] <- "1,000 - 10,000"
  temp$ice.col[temp$ICER>=10000 & temp$ICER<30000] <- "10,000 - 30,000"
  temp$ice.col[temp$ICER>=30000 & temp$ICER<50000] <- "30,000 - 50,000"
  temp$ice.col[temp$ICER>=50000] <- "50,000 +"
  temp$ice.col = factor(temp$ice.col,levels=c(
    "1,000 or below",
    "1,000 - 10,000",
    "10,000 - 30,000",
    "30,000 - 50,000",
    "50,000 +"),ordered=TRUE)
  
  color.vec <- c("1,000 or below"=cols[10], 
                 "1,000 - 10,000"=cols[9],
                 "10,000 - 30,000"=cols[7],
                 "30,000 - 50,000"=cols[4],
                 "50,000 +"=cols[2])
  
## colors
  colors <- viridis(n=10)
  colors.2 <- inferno(n=5)
  
## prep the dataset
  d <- temp[,c("int_des_short","delta.deaths","delta.deaths.LB","delta.deaths.UB","che.10","che.10.LB","che.10.UB")]
  d <- melt(d)
  d$mean <- 0
  d$mean[d$variable %in% c("delta.deaths","che.10")] <- 1
  d$variable[d$variable %in% c("delta.deaths.LB","delta.deaths.UB")] <- "delta.deaths"
  d$variable[d$variable %in% c("che.10.LB","che.10.UB")] <- "che.10"
  d <- merge(d,temp[,c("int_des_short","che.10")],by="int_des_short")
  
  d$variable <- as.character(d$variable)
  d$variable[d$variable %in% c("delta.deaths")] <- "Deaths"
  d$variable[d$variable %in% c("che.10")] <- "Catastrophic Health Expenditures"
  d$mean.val <- NA
  d$mean.val[d$mean == 1] <- d$value[d$mean == 1]
  d$above <- 0
  d$above[d$value>=4000] <- 1
 
# make the plot
  d1 <- d[d$variable=="Deaths",]
  d2 <- d[d$variable=="Catastrophic Health Expenditures",]
  
  p1 <- ggplot(data=d1, aes(x=fct_reorder(int_des_short, che.10),y=value,color=as.factor(variable))) +
              geom_line(lwd=2,position=position_dodge(width = 0.5)) +
              geom_point(size=4,position=position_dodge(width = 0.5)) +
              xlab("") +
              ylab("Deaths averted") + 
              theme(axis.title.y = element_text(size=20,family="serif")) +
              theme(axis.text.y = element_text(size=20,family="serif")) +
              theme(axis.text.x = element_text(size=12,hjust=1,angle=45,family="serif")) +
              theme(plot.margin = unit(c(0.5,0.5,0.5,3), "lines")) +
              theme(legend.position = "none") +
              labs(color = "") +
              scale_color_manual(values = c(colors[1])) +
              theme(legend.text=element_text(size=20,family="serif")) +
              annotate("text",x=18.5,y=1129,label="Upper Est.",family="serif") +
              annotate("text",x=18.5,y=956,label="Mean Est.",family="serif") +
              annotate("text",x=18.5,y=728,label="Lower Est.",family="serif") 
    
    p2 <- ggplot(data=d2, aes(x=fct_reorder(int_des_short, che.10),y=value,color=as.factor(variable))) +
              geom_line(lwd=2,position=position_dodge(width = 0.5)) +
              geom_point(size=4,position=position_dodge(width = 0.5)) +
              xlab("") +
              ylab("CHE 10% averted") + 
              theme(axis.title.y = element_text(size=20,family="serif")) +
              theme(axis.text.y = element_text(size=20,family="serif")) +
              theme(axis.text.x = element_text(size=12,hjust=1,angle=45,family="serif")) +
              theme(plot.margin = unit(c(0.5,0.5,0.5,3), "lines")) +
              theme(legend.position = "none") +
              labs(color = "") +
              scale_color_manual(values = c(colors[4])) +
              theme(legend.text=element_text(size=20,family="serif")) +
              annotate("text",x=17.5,y=212902,label="Upper Est.",family="serif") +
              annotate("text",x=17.5,y=161902,label="Mean Est.",family="serif") +
              annotate("text",x=17.5,y=122379,label="Lower Est.",family="serif") 

# save the plot  
  pdf("./04_figures/FIGURE_2.pdf",height=11,width=8) 
       grid.arrange(p1,p2,nrow=2)
  dev.off() 
  
  
  