## Author:  Kate Lofgren
## Date:    8/3/2019
## Purpose: Appendix Table: Disease Burden Targets

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(lpSolve)
  library(reshape2)
  library(viridis)
  library(gdata)

## set seed
  set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")

## bring in the data
  am <- read.xls(file,sheet="Disease Burden",stringsAsFactors=F)
  am <- am[,2:11]
  names(am) <- c("int_n","int_des","gbd_n","gbd_id","gbd_des","burden_age","time_lag","burden_amenable",
                  "Source(s)","Details")
  
## merge in the sex from the target pop
  temp <- read.xls(file,sheet="Target Pop",stringsAsFactors=F)
  temp$X <- temp$X.1 <- temp$X.2 <- temp$X.3 <- NULL
  names(temp) <- c("int_n","int_des","gbd_n",
                   "target_type","target_pop",
                   "target_age","target_sex")
  temp <- temp[,c("int_n","target_sex")]
  temp <- unique(temp)
  am <- merge(am,temp,by=c("int_n"))
  
## limit variables for table
  data <- am
  data <- data[,c("int_n","int_des","gbd_des","burden_age","target_sex","burden_amenable","Source(s)","Details")]
  data$burden_amenable <- data$burden_amenable*100
  
## create better names for appendix table
  names(data)[1:6] <- c("Intervention #",
                   "Intervention",
                   "Disease category",
                   "Age",
                   "Sex","Addressable (%)")
  
## fix capitalization on sex
  data$Sex[data$Sex=="females"] <- "Females"
  data$Sex[data$Sex=="males"] <- "Males"
  
## fix age groups to be month/year specific
  data$Age[data$Age=="15-49"] <- "15-49 years"
  data$Age[data$Age=="15-69"] <- "15-69 years"
  data$Age[data$Age=="0-69"] <- "0-69 years"
  data$Age[data$Age=="20-69"] <- "20-69 years"
  data$Age[data$Age=="30-69"] <- "30-69 years"
  data$Age[data$Age=="Under-5"] <- "0-4 years"
  
# save the table
  write.table(data,"./05_tables/TABLE_APPENDIX_8_Burden_Targets.csv",sep=",",row.names=F)
  
  