## Author:  Kate Lofgren (kate.lofgren@g.harvard.edu)
## Date:    8/25/2018
## Purpose: Graph results

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(ggplot2)
  library(gridExtra)
  library(gdata)
  library(ggExtra)
  library(viridis)
  library(RColorBrewer)
  library(forcats)
  
## set seed
  set.seed(02139)
  options(scipen = 999)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")
  
## bring in data
  data <- read.table("./03_output_data/05_optimized_interventions_single_obj_package.csv", sep=",", header=T, stringsAsFactors=F)
  package <- read.table("./03_output_data/05_optimized_package_counts_single_obj_package.csv", sep=",", header=T, stringsAsFactors=F)
  
## colors
  colors <- viridis(n=10)
  colors.1 <- brewer.pal(n=10,"BrBG")
  colors.2 <- inferno(n=10)
  
############################################################## 
## graph of deaths / CHE averted across budgets
##############################################################  
  package$budget                <- package$budget/1000000
  x <- 1000
  package$package.deaths        <- package$package.deaths/x
  package$package.che.10        <- package$package.che.10/x
  
  death.pack <- package[package$objective=="delta.deaths" & 
                          package$budget %in% c(1,seq(0,100,5)),]
  che.10.pack <- package[package$objective=="che.10" & 
                           package$budget %in% c(1,seq(0,100,5)),]
 
  ## figure out y-axis max
  max <- max(package$package.deaths,package$package.che.10,package$package.che.25)
  
  ## colors
  colors <- viridis(n=10)
  colors.2 <- inferno(n=5)
 
################################################################
## Panel Version across budgets and across single objectives ###
## delta.deaths, che.10, che.25                              ###
################################################################
pdf("./04_figures/FIGURE_APPENDIX_2.pdf",height=6,width=11) 
  
par(xpd=FALSE,mar = c(6.5, 6.5, 4.5, 1), mgp = c(4.75, 1, 0),mfrow=c(1,2))
  
## plot 1
  plot(death.pack$budget,death.pack$package.deaths,ylim=c(0,max),
       pch="",col="black",cex=2,xlab="Budget (millions USD)",ylab="Cases Averted (1000s)",
       cex.lab=1.75,cex.axis=1.75,lwd=4,las=1,main="A: Maximize \nPopulation Health",cex.main=1.3,family="serif")
        # plot lines when optimized on deaths averted 
        # CHE 10% averted
        points(death.pack$budget,
               death.pack$package.che.10,pch=19,cex=1.5,col=colors[4])
        lines(death.pack$budget,death.pack$package.che.10,lwd=3,col=colors[4])
        
        # deaths averted
        points(death.pack$budget,
               death.pack$package.deaths,pch=19,cex=1.5,col=colors[1])
        lines(death.pack$budget,death.pack$package.deaths,lwd=3,col=colors[1])
        
        # add annotations
        par(xpd=TRUE)
        text(x=90,y=400, labels="CHE 10%", cex=1.25, col=colors[4],family="serif")
        text(x=90,y=50, labels="Deaths", cex=1.25, col=colors[1],family="serif")
     
        
## plot 2
        plot(death.pack$budget,death.pack$package.deaths,ylim=c(0,max),
             pch="",col="black",cex=2,xlab="Budget (millions USD)",ylab="",
             cex.lab=1.75,cex.axis=1.75,lwd=4,las=1,
             main="B: Maximize \nFinancial Risk Protection",cex.main=1.3,family="serif")
  
        # plot lines when optimized on CHE 10% averted 
        # deaths averted
        points(che.10.pack$budget,
               che.10.pack$package.deaths,pch=19,cex=1.5,col=colors[1])
        lines(che.10.pack$budget,che.10.pack$package.deaths,lwd=3,col=colors[1])
        
        # CHE 10% averted
        points(che.10.pack$budget,
               che.10.pack$package.che.10,pch=19,cex=1.5,col=colors[4])
        lines(che.10.pack$budget,che.10.pack$package.che.10,lwd=3,col=colors[4])
        
        # add annotations
        par(xpd=TRUE)
        text(x=90,y=550, labels="CHE 10%", cex=1.25, col=colors[4],family="serif")
        text(x=90,y=50, labels="Deaths", cex=1.25, col=colors[1],family="serif")
  dev.off()     
 