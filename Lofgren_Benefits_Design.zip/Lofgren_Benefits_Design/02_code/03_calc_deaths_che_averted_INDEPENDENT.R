## Author:  Kate Lofgren (klofgren@g.harvard.edu)
## Date:    8/13/2018
## Purpose: Calculate deaths and CHE averted for downstream care

## set up
  rm(list=ls())
  date <- Sys.Date()
  options(scipen = 9999)
  
## libraries
  library(foreign)
  library(gdata)
  
## set seed
  set.seed(02139)
  
## set directory
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")
  
## bring in income draws
  hh.incomes <- read.table("./03_output_data/income_draws.csv",sep=",",header=T)
  names(hh.incomes) <- "hh.incomes"
  
## bring in temporal spacing to map intervention information
  print("USING FILE:")
  print(file)
  
  map <- read.xls(file,sheet="Temporal Spacing",stringsAsFactors=F)
  names(map)[1] <- "gbd_n"
  
  ## for this, keep int=1 with no int 2 and int 2's
  map$int_n <- NA
  map$int_n[is.na(map$int_2_n)] <- map$int_1_n[is.na(map$int_2_n)]
  map$int_n[!is.na(map$int_2_n)] <- map$int_2_n[!is.na(map$int_2_n)]
  map <- map[,c("gbd_n","int_n")]
  
  ## create a list of all the interventions we should have at end of code for error checking
  check <- unique(map$int_n)
  check[which(check %in% c(3.1,3.3))] <- 3
  check[which(check %in% c(4.1,4.2))] <- 4
  check <- unique(check)
  
## bring in input parameter master file(s)
  data <- read.csv("./01_input_data/02_final_input_parameters.csv",header=T,stringsAsFactors=F)
  
## merge intervention info onto mapping file
  data <- merge(map,data,by=c("gbd_n","int_n"),all.x=T)
  
## make a indicator for cases where incidence = 0
  data$zero.incidence <- 0
  data$zero.incidence[data$incidence==0] <- 1
  
# create a variable for OOP cost as a percent
  data$oop.cost.per <- data$oop.cost
  data$oop.cost <- NA 
    
# keep a master file to pull variables from
  master <- data
  
############################################
## Loop over potential LB/UB scenarios    ##
############################################
# create a ticker
ticker <- 0
  
for(e in c("MEAN","LB","UB")) {
  if(e=="MEAN") {
    int_eff <- master$int_eff
  } else if(e=="LB") {
    int_eff <- master$int_eff_LB
  } else {
    int_eff <- master$int_eff_UB
  }
  for(s in c("MEAN","LB","UB")) {
    ## assign the right varaibles - set up
    if(s=="MEAN") {
      ## average
      target_n <- master$target_n
      incidence <- master$incidence
      CFR <- master$CFR
      deaths <- master$deaths
    } else if(s=="LB") {
      # LB
      target_n <- master$target_n_LB
      incidence <- master$incidence_LB
      CFR <- master$CFR_LB
      deaths <- master$deaths_LB
    } else {
      # UB
      target_n <- master$target_n_UB
      incidence <- master$incidence_UB
      CFR <- master$CFR_UB
      deaths <- master$deaths_UB
    }
    
    # add 1 to ticker
    ticker <- ticker + 1
    
    ## calculate the newly treated population
        data$new_tx_pop <- NA
        ## 1 - when intervention target is incidence or prevalence -- include burden addressable variable
        data$new_tx_pop[data$int_target != "population"] <- cov.delta *
                                                            target_n[data$int_target != "population"] *
                                                            data$burden_amenable[data$int_target != "population"] 
        ## 2 - when intervention target is population -- goes to everyone -- don't want addressable %
        data$new_tx_pop[data$int_target == "population"] <- cov.delta *
                                                            target_n[data$int_target == "population"] 
        ## 3 - CEmOC is an exception where the "population" is all births and only 17% need CEmOC
        data$new_tx_pop[data$int_n == 4] <- cov.delta *
                                            target_n[data$int_n == 4] *
                                            data$burden_amenable[data$int_n == 4] 
        
    ## calculate the population previously seeking care -- that are now covered (i.e. the baseline coverage pop)
        data$baseline_coverage_pop <- NA
        ## 1 - when intervention target is incidence or prevalence -- include burden addressable variable
        data$baseline_coverage_pop[data$int_target != "population"] <- data$baseline_cov[data$int_target != "population"] *
                                                                      target_n[data$int_target != "population"] *
                                                                      data$burden_amenable[data$int_target != "population"] 
        
        ## 2 - when intervention target is population -- goes to everyone -- don't want addressable %
        data$baseline_coverage_pop[data$int_target == "population"] <- data$baseline_cov[data$int_target == "population"] *
                                                                       target_n[data$int_target == "population"] 
        
        ## 3 - CEmOC is an exception where the "population" is all births and only 17% need CEmOC
        data$baseline_coverage_pop[data$int_n == 4] <- data$baseline_cov[data$int_n == 4] *
                                                       target_n[data$int_n == 4] *
                                                       data$burden_amenable[data$int_n == 4] 
        
    ## calculate the total cost of scaling up coverage
    ## whole unit cost for newly covered, just OOP for baseline coverage
    data$total_cost <- (data$new_tx_pop*data$unit.cost) + (data$baseline_coverage_pop*data$oop.cost.per*data$unit.cost)
        
    ## covert OOP to dollars instead of %
    data$oop.cost <- data$oop.cost.per*data$unit.cost
    
    ## covert OOP for screen/treat costs to dollars instead of %
    data$oop.cost.screen <- data$oop.cost.per*data$uc.screen
    data$oop.cost.treat <- data$oop.cost.per*(data$uc.treat + data$uc.screen) # both screened and treated
    
    #################################
    ## Deaths averted per $ spent  ##
    ################################# 
    ## Change in deaths is just for the newly covered
    ## Calculations for when efficacy estimate is for INCIDENCE
    data$delta.incidence <- NA
    i <- which(data$int_eff_target=="incidence")
    data$delta.incidence[i] <- cov.delta*int_eff[i]*data$burden_amenable[i]*incidence[i]
    
    
    ## for changes in incidence, now calculate delta deaths based on change in case fatality ratio
    data$delta.deaths <- NA
    data$delta.deaths[i] <- CFR[i]*data$delta.incidence[i]
    
    ## Calculations for when efficacy estimate is for MORTALITY
    m <- which(data$int_eff_target=="mortality")
    data$delta.deaths[m] <-   cov.delta*
                              int_eff[m]*
                              data$burden_amenable[m]*
                              deaths[m]
    
    
    #############################
    ## CHE averted per $ spent ##
    #############################
    ## Change in CHE is for both newly and baseline covered
    ## loop by row
    for(r in 1:dim(data)[1]) {
      ## two calcs for screen/treat interventions
      if(data$screen[r] == 1) {
        ## draw subset of incomes for both screen and treat
        i.screen <- runif(n=round((data$new_tx_pop[r] + data$baseline_coverage_pop[r])*(1-data$p.treat[r])),min=1,max=total.draws) 
        i.treat <- runif(n=round((data$new_tx_pop[r] + data$baseline_coverage_pop[r])*(data$p.treat[r])),min=1,max=total.draws) 
        tx.incomes.screen <- hh.incomes[i.screen,]
        tx.incomes.treat <- hh.incomes[i.treat,]
        
        ## calculate the percent of income OOP represents
        i.per.screen <- data$oop.cost.screen[r]/tx.incomes.screen
        i.per.treat <- data$oop.cost.treat[r]/tx.incomes.treat
        
        ## generate counts of CHE averted at all cutoffs
        che.counts <- vector()
        
        index <- 0
        for(c in cutoffs) {
          index <- index + 1
          che.counts[index] <- length(which(i.per.screen >= c)) + length(which(i.per.treat >= c))
        }
        data$che.10[r] <- che.counts[1]
        data$che.25[r] <- che.counts[2]
      } else {
        ## one calc for most interventions
        ## draw subset of incomes
        i <- runif(n=round(data$new_tx_pop[r] + data$baseline_coverage_pop[r]),min=1,max=total.draws) 
        tx.incomes <- hh.incomes[i,]
        
        ## calculate the percent of income OOP represents
        i.per <- data$oop.cost[r]/tx.incomes
        
        ## generate counts of CHE averted at all cutoffs
        che.counts <- vector()
        
        index <- 0
        for(c in cutoffs) {
          index <- index + 1
          che.counts[index] <- length(which(i.per >= c))
        }
        data$che.10[r] <- che.counts[1]
        data$che.25[r] <- che.counts[2]
      } # closes if/else loop
    }  # closes row loop
    
    
    ## generate time-lag discounted versions
    data$t <- NA
    data$t[data$time_lag=="Immediate"] <- 0
    data$t[data$time_lag=="5 years"] <- 5
    data$t[data$time_lag=="10 years"] <- 10
    data$delta.deaths.npv <- data$delta.deaths/(1.03^data$t)
    
    # add variables to track what uncertainty scenarios are being used
    data$int_eff_uncert <- e
    data$pop_burden_uncert <- s

    ## save file with all vars
    if(ticker==1) {
      save <- data
    } else {
      save <- rbind(save,data)
    }
  } # closes the loop for burden/pop uncertainty scenarios
} # closes loop for intervention risk reduction uncertainty scenarios

## save aggregate file with all possible scenarios
  write.table(save,paste0("./03_output_data/03_IND_all_vars.csv"),sep=",",row.names=F)
  
###### aggregate the results for each scenario ##########
ticker2 <- 0
for(e in c("MEAN","LB","UB")) {
  for(s in c("MEAN","LB","UB")) {
    ticker2 <- ticker2 + 1

    ## keep just the relevant data for a specific scenario
    data <- save[save$int_eff_uncert==e & save$pop_burden_uncert==s,]
    
    ## collapse the dataset so that each intervention is one row
    ## for maternal -- want just overall cost of SBA, BEmOC, CEmOC with added deaths etc. from 3.1-3.3 and 4.1-4.2
    mat <- data[data$int_n %in% c(3.1,3.2,3.3,4.1,4.2),]
    mat$int_n[mat$int_n %in% c(3.1,3.2,3.3)] <- 3
    mat$int_n[mat$int_n %in% c(4.1,4.2)] <- 4
    i.3.4 <- aggregate(cbind(delta.deaths,
                             delta.deaths.npv,
                             che.10,
                             che.25) ~
                             int_n, FUN=sum, data=mat)
    
    # combine maternal and neonatal for BEmOC and CEmOC
    data$delta.deaths[data$int_n==3] <- data$delta.deaths[data$int_n==3] + i.3.4$delta.deaths[i.3.4$int_n==3]
    data$delta.deaths[data$int_n==4] <- data$delta.deaths[data$int_n==4] + i.3.4$delta.deaths[i.3.4$int_n==4]
    
    data$delta.deaths.npv[data$int_n==3] <- data$delta.deaths.npv[data$int_n==3] + i.3.4$delta.deaths.npv[i.3.4$int_n==3]
    data$delta.deaths.npv[data$int_n==4] <- data$delta.deaths.npv[data$int_n==4] + i.3.4$delta.deaths.npv[i.3.4$int_n==4]
    
    data$che.10[data$int_n==3] <- data$che.10[data$int_n==3] + i.3.4$che.10[i.3.4$int_n==3]
    data$che.10[data$int_n==4] <- data$che.10[data$int_n==4] + i.3.4$che.10[i.3.4$int_n==4]
    
    data$che.25[data$int_n==3] <- data$che.25[data$int_n==3] + i.3.4$che.25[i.3.4$int_n==3]
    data$che.25[data$int_n==4] <- data$che.25[data$int_n==4] + i.3.4$che.25[i.3.4$int_n==4]
    
    
    ## save master data for interventions 3 and 4
    i.mat <- data[data$int_n %in% c(3,4),c("int_n","int_des","total_cost",
                                           "delta.deaths",
                                           "delta.deaths.npv",
                                           "che.10",
                                           "che.25")]
    
    ## for disease targets -- want to add total costs (b/c specific target pops) + delta.deaths + che
    i.disease <- aggregate(cbind(total_cost,
                                 delta.deaths,
                                 delta.deaths.npv,
                                 che.10,
                                 che.25) ~ int_n + int_des,
                           FUN=sum,data[data$int_target=="incidence" | data$int_target=="prevalence",], na.rm=T)
    
    ## get rid of BEmOC and CEmOC since we already have those from above
    i.disease <- i.disease[i.disease$int_n != 3.1 & i.disease$int_n != 3.2
                           & i.disease$int_n != 3.3 &
                             i.disease$int_n != 4.1 & i.disease$int_n != 4.2,]
    
    ## for population targets -- just want overall cost (don't double count) + additive delta.deaths + che across disease categories
    i.population <- aggregate(cbind(delta.deaths,
                                    delta.deaths.npv,
                                    che.10,
                                    che.25) ~ int_n + int_des,
                              FUN=sum,data[data$int_target=="population",], na.rm=T)
    
    i.pop.cost <- unique(data[data$int_target=="population",c("int_n","total_cost")]) # merging in total cost here to avoid double count
    i.population <- merge(i.population,i.pop.cost,by=c("int_n"),all.x=T)
    
    ## get rid of BEmOC and CEmOC since we already have those from above
    i.population <- i.population[i.population$int_n != 3 & i.population$int_n != 4,]
    
    ## put all these files together
    data <- rbind(i.mat,i.disease,i.population)
    data <- data[order(data$int_n),]
    
    # check to make sure all the interventions are accounted for
    sort(check) == sort(data$int_n)
    
    ## add variables to track uncertainty scenario
    data$int_eff_uncert <- e
    data$pop_burden_uncert <- s
    
    ## save file with all vars
    if(ticker2==1) {
      save2 <- data
    } else {
      save2 <- rbind(save2,data)
    }
  } # closes the file aggregation loop for pop/burden uncertainty
} # closes the aggregation loop for int effect uncertainty

## save file with key vars
  write.table(save2,paste0("./03_output_data/03_IND_deaths_che.csv"),sep=",",row.names=F)
  
  
  