## Author:  Kate Lofgren
## Date:    8/3/2019
## Purpose: Graph full feasability space with budget panels

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(lpSolve)
  library(reshape2)
  library(viridis)

## set seed
  set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")

## bring in the data
  pc <- read.table("./03_output_data/05_optimized_package_counts_full_frontier.csv",sep=",",header=T,stringsAsFactors=F)

## keep one budget
  pc <- pc[pc$budget==10000000,]

## get rid of the zeros -- these constraints (k) where too large
  pc <- pc[pc$package.deaths!=0 | pc$package.che.10!=0,]
  pc <- pc[,c("objective","package.deaths","package.che.10","constraint")]
  pc <- unique(pc)  

## save a file with the single objectives for plot
  d.max <- max(pc$package.deaths[pc$objective=="delta.deaths"]) 
  che.max <- max(pc$package.che.10[pc$objective=="che.10"])
  single <- pc[(pc$package.deaths>=d.max | pc$package.che.10 >=che.max) & pc$constraint=="<=",]

## create a cohesive set of points to plot for the pareto frontier that combine deaths and CHE info
  front <- pc[pc$constraint==">=",]
  front <- front[order(front$package.deaths),]
  front <- front[c("package.deaths","package.che.10")]
  front <- unique(front)    

## figure out the ylim and xlim values
  max.budget <- 30000000
  temp <- read.table("./03_output_data/05_optimized_package_counts_full_frontier.csv",sep=",",header=T,stringsAsFactors=F)
  
  ## for now just keep one budget
  temp <- temp[temp$budget==max.budget,] 
  x.max <- max(temp$package.che.10)
  y.max <- max(temp$package.deaths)
  
###################################################################################
####### plot the feasable space and the pareto frontier / optimal solutions #######
###################################################################################

# create a color palette for the plot
  colors <- viridis(10)
  colors2 <- plasma(10)

# start plot
  pdf("./04_figures/FIGURE_4.pdf",height=8,width=18)

# plot code
  par(xpd=FALSE,mar = c(5.5, 6.5, 2.5, 2.5), mgp = c(4.75, 1, 0),mfrow=c(1,2))
  
## BUDGET 1: 40 Million ###########################################
      plot(pc$package.che.10[pc$objective=="delta.deaths"],pc$package.deaths[pc$objective=="delta.deaths"],
           pch="",ylim=c(0,y.max+1000),xlim=c(0,x.max+5000),
           ylab="",
           xlab="",
           main="A: 10 Million USD Budget",
           las=1,cex.lab=2,cex.axis=1.5,cex.main=2,family="serif")
      
      ## add in y axis label
      title(ylab = "Deaths Averted", cex.lab = 2,
            line = 4.5,family="serif")
      title(xlab = "Catastrophic Health Expenditures Averted", cex.lab = 2,
            line = 3.5,family="serif")
      
      # lines for feasible bounds
      lines(pc$package.che.10[pc$objective=="delta.deaths" & pc$constraint=="<="],
            pc$package.deaths[pc$objective=="delta.deaths"& pc$constraint=="<="],lwd=3,col="gray35")
      lines(pc$package.che.10[pc$objective=="che.10"& pc$constraint=="<="],
            pc$package.deaths[pc$objective=="che.10"& pc$constraint=="<="],lwd=3,col="gray35")
      
      # points and lines for the frontier
      points(front$package.che.10,
             front$package.deaths,pch=19,cex=2,col=colors[5])
      lines(front$package.che.10,
            front$package.deaths,lwd=3,col=colors[5])
      
      ## optimal solutions for single objectives
      ## Deaths
      points(single$package.che.10[single$objective=="delta.deaths"],
             single$package.deaths[single$objective=="delta.deaths"],pch=19,cex=2.7,col=colors2[5])
      text(x=single$package.che.10[single$objective=="delta.deaths"]+75000,
           y=single$package.deaths[single$objective=="delta.deaths"]+150, 
           labels="Optimal solution at or above\n1 : 3 valuation", 
           cex=1.5, col=colors2[5],family="serif")
   

      ## ADD INDIFFERENCE CURVE
      abline(a=4824,b=-(.0267),lwd=4,lty=2,col="black")
      text(x=135000,y=4500, 
           labels="Indifference Line: 1 Death = 3 CHE cases", 
           cex=1.5, col="black",family="serif")
      
## BUDGET 1: 60 Million ######################################################
      pc <- read.table("./03_output_data/05_optimized_package_counts_full_frontier.csv",sep=",",header=T,stringsAsFactors=F)
      pc <- pc[pc$budget==30000000,] ## Range 0 - 14,000
      
      ## get rid of the zeros -- these constraints (k) where too large
      pc <- pc[pc$package.deaths!=0 | pc$package.che.10!=0,]
      pc <- pc[,c("objective","package.deaths","package.che.10","constraint")]
      pc <- unique(pc)  
      
      ## save a file with the single objectives for plot
      d.max <- max(pc$package.deaths[pc$objective=="delta.deaths"]) 
      che.max <- max(pc$package.che.10[pc$objective=="che.10"])
      single <- pc[(pc$package.deaths>=d.max | pc$package.che.10 >=che.max) & pc$constraint=="<=",]
      
      ## create a cohesive set of points to plot for the pareto frontier that combine deaths and CHE info
      front <- pc[pc$constraint==">=",]
      front <- front[order(front$package.deaths),]
      front <- front[c("package.deaths","package.che.10")]
      front <- unique(front)    
      
      ## make the plot with new data
      plot(pc$package.che.10[pc$objective=="delta.deaths"],pc$package.deaths[pc$objective=="delta.deaths"],
           pch="",ylim=c(0,y.max+1000),xlim=c(0,x.max+5000),
           ylab="",
           xlab="",
           main="B: 30 Million USD Budget",
           las=1,cex.lab=2,cex.axis=1.5,cex.main=2,family="serif")
      
      ## add in y axis label
      title(ylab = "Deaths Averted", cex.lab = 2,
            line = 4.5,family="serif")
      title(xlab = "Catastrophic Health Expenditures Averted", cex.lab = 2,
            line = 3.5,family="serif")
      
      # lines for feasible bounds
      lines(pc$package.che.10[pc$objective=="delta.deaths" & pc$constraint=="<="],
            pc$package.deaths[pc$objective=="delta.deaths"& pc$constraint=="<="],lwd=3,col="gray35")
      lines(pc$package.che.10[pc$objective=="che.10"& pc$constraint=="<="],
            pc$package.deaths[pc$objective=="che.10"& pc$constraint=="<="],lwd=3,col="gray35")
      
      # points and lines for the frontier
      points(front$package.che.10,
             front$package.deaths,pch=19,cex=2,col=colors[5])
      lines(front$package.che.10,
            front$package.deaths,lwd=3,col=colors[5])
      
      ## optimal solutions for single objectives
      ## Deaths
      points(single$package.che.10[single$objective=="delta.deaths"],
             single$package.deaths[single$objective=="delta.deaths"],pch=19,cex=2.7,col=colors2[5])
      text(x=single$package.che.10[single$objective=="delta.deaths"]+6500,
           y=single$package.deaths[single$objective=="delta.deaths"]+400, 
           labels="Optimal solution at or above\n1 : 0.2 valuation", 
           cex=1.5, col=colors2[5],family="serif")
      
      ## ADD INDIFFERENCE CURVEs
      abline(a=5142,b=-(.002),lwd=4,lty=2)
      text(x=245000,y=5200, 
           labels="Indifference Line:\n1 Death = 0.2 CHE cases", 
           cex=1.5, col="black",family="serif")
      
dev.off()
