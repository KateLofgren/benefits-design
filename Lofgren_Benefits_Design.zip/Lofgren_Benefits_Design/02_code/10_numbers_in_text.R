## Author:  Kate Lofgren (klofgren@g.harvard.edu)
## Date:    8/31/2020
## Purpose: Numbers cited in text

## bring in parameters
  rm(list=ls())
  set.seed(02139)
  library(foreign)
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")


## Price tag of basic surgery and hypertension screen/control
  data <- read.csv("./03_output_data/04_combined_decision_vars.csv",header=T)
  # most expensive interventions
  data <- data[order(-data$total_cost),]
  data$int_des[1] # basic surgery
  data$int_des[2] # screen/control hypertension
  
  # intervention specific price tags
  round(data$total_cost[data$int_des=="Basic package of quality surgical services"]/1000000,0) # 21
  round(data$total_cost[data$int_des=="Screening and control of hypertension"]/1000000,0) # 14
  
# Intervention changes from 60 to 65 million (panel C on figure 5)a
  data <- read.table("./03_output_data/05_optimized_interventions_single_obj.csv", sep=",", header=T, stringsAsFactors=F)
  temp <- data[data$objective=="delta.deaths" & data$budget %in% c(60000000,65000000),]
  temp2 <- aggregate(fund ~ int_n,FUN=sum,data=temp)
  int.list <- temp2[temp2$fund==1,] # only funded at one of the two budgets
  temp3 <- temp[temp$int_n %in% c(int.list$int_n),]
  temp3 <- temp3[order(temp3$int_n,temp3$budget),]
  temp3
  ## SBA and Mat. BP screen/treat dropped, surgery added
  
  # total number of CHE cases and deaths attributable to basic surgery inclusion
  data <- read.csv("./03_output_data/04_combined_decision_vars.csv",header=T)
  data$che.10[data$int_n==20] #161,902 CHE cases
  round(data$delta.deaths[data$int_n==20],0) # 356 deaths
  