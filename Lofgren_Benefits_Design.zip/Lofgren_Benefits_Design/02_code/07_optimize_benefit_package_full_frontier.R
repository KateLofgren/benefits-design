## Author:  Kate Lofgren (klofgren@g.harvard.edu)
## Date:    8/18/2018
## Purpose: Calculate the optimal intervention package

## Note:    In this version focusing on an exhaustive feasability creation. 
###         This adds computation time so is limited to one budget and just deaths / che.10 right now
###         This version does not include temporal dependency constraints 

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(lpSolve)
  library(reshape2)
  library(viridis)

## set seed
  set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")

## bring in intervention data
  data <- read.table("./03_output_data/04_combined_decision_vars.csv", sep=",", header=T)

## figure out required K values based on constraint
  k.range <- read.table("./03_output_data/05_optimized_package_counts_single_obj.csv",sep=",",header=T)
  k.range <- k.range[,c("objective","package.deaths","package.che.10","package.che.25")]
  k.range <- k.range[k.range$objective %in% c("che.10","che.25","delta.deaths"),]


  k.che <- c(0,max(k.range$package.che.10[k.range$objective=="che.10"])) # want the max when che max on che
  k.deaths <- c(0,max(k.range$package.deaths[k.range$objective=="delta.deaths"])) # want the max when deaths max on deaths
  
## budgets to be considered for the whole frontier
  b <- seq(10000000, 100000000,10000000)
  
## make a master holding file
  results.che <- expand.grid(int_n=unique(data$int_n),objective=c("che.10"),
                                                              budget=b,
                                                              k=seq(k.deaths[1],k.deaths[2],100),
                                                              constraint=c("<=",">="),
                                                              fund=NA)
  
  results.deaths <- expand.grid(int_n=unique(data$int_n),objective=c("delta.deaths"),
                             budget=b,
                             k=seq(k.che[1],k.che[2],100),
                             constraint=c("<=",">="),
                             fund=NA)
  
for(o in c("delta.deaths","che.10")) {
  ## optimize package testing
  # o <- "delta.deaths"
  # o <- "che.10"
  # b <- 6000000
  # c <- 2
  # k <- 1000
 
  print("**********************")
  print(paste0("on objective ",o))
  
  for(b in unique(results.deaths$budget)) { # doesn't matter that this references a death specific dataset
    print(paste0("on budget ",b))
    
      ## assign the secondary objective
      if(o %in% c("delta.deaths")) {
        o.2 <- "che.10"
        k.vec <- seq(k.che[1],k.che[2],100) # the opposite of the objective
      } else {
        o.2 <- "delta.deaths"
        k.vec <- seq(k.deaths[1],k.deaths[2],100) # the opposite of the objective
      } # if/else loop 
    
      for(k in k.vec) {
        ## to keep track of progress
        if(k %in% seq(0,13000,1000)) {
          print(paste0("on K constraint ",k))
        }
        
        for(c in unique(results.deaths$constraint)) { # doesn't matter that this references a death specific dataset
          #####################################
          ## Define Optimization Components ###
          #####################################
          ## make sure there is 1 row for each intervention
          20 == dim(data)[1]
          
          ## step 1: vector of objective
          objective.in  <- data[[o]]
          
          ## step 2: create constraint martix 
            ## constraint 1: cost can't exceed budget
            c1 <- data$total_cost 
            
            ## constraint 2: secondary objective
            c2 <- data[[o.2]]
          
          ## combine all constraints into a matrix
          const.mat <- matrix(c(c1,c2),nrow=2, byrow=TRUE)
          
          ## define the constraint bounds
          const.rhs <- c(b,k)
          
          ## define the direction of the constraints
          if(c == "<=") {
            const.dir  <- c("<=","<=") 
          } else {
            const.dir  <- c("<=",">=") 
          }
          
          ##########################
          ## Run the Optimization ##
          ##########################
          ## Find the optimal solution (includes a binary decision variable argument)
          optimum <-  lp(direction="max",  objective.in, const.mat, const.dir, const.rhs, all.bin=TRUE)
          
          ## save the results
          if(o == "delta.deaths") {
            results.deaths[results.deaths$objective==o & 
                            results.deaths$budget==b & 
                            results.deaths$k==k & 
                            results.deaths$constraint==c,c("fund")] <- optimum$solution
          } else {
            results.che[results.che$objective==o & 
                             results.che$budget==b & 
                             results.che$k==k & 
                             results.che$constraint==c,c("fund")] <- optimum$solution
          }
        
          
        } # constraint direction loop
      } # (k) constant value loop
  } # budget loop 
} # objective loop

## combine the two results files
  results <- rbind(results.che,results.deaths)
  
## save files
  write.table(results,"./03_output_data/05_optimized_interventions_full_frontier.csv",sep=",",row.names=F)
 
## create a file with the total cost, deaths averted, and lives saved for benefit packages
  data <- data[,c("int_n","int_des","total_cost","delta.deaths","che.10","che.25")]
  data <- unique(data)
  20 == dim(data)[1]
  results <- merge(results,data,by="int_n",all.x=T)
  results <- results[order(results$int_n,results$int_des,results$objective,results$budget,results$k, results$constraint),]
  
  # cost of programs and total deaths/che averted
  results$package.cost <- results$total_cost*results$fund
  results$package.deaths <- results$delta.deaths*results$fund
  results$package.che.10 <- results$che.10*results$fund
  results$package.che.25 <- results$che.25*results$fund
  
  pc <- aggregate(cbind(package.cost,package.deaths,package.che.10,package.che.25) ~ 
                    objective + budget + k + constraint,FUN=sum,data=results)
  
## save files
  write.table(pc,"./03_output_data/05_optimized_package_counts_full_frontier.csv",sep=",",row.names=F)

