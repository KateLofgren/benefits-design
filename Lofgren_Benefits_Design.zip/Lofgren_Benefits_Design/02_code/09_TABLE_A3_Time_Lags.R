## Author:  Kate Lofgren
## Date:    8/3/2019
## Purpose: Appendix Table: Time Lags

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(lpSolve)
  library(reshape2)
  library(viridis)

## set seed
  set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")
  
## bring in the data
  data <- read.xls(file,sheet="Disease Burden",stringsAsFactors=F)
  data <- data[,2:9]
  names(data) <- c("Intervention #",
                   "Intervention",
                   "GBD.Disease.Category",
                   "gbd_id","GBD.Disease.Category.Description",
                   "Burden.Age.Group",
                   "Average Benefit Timing","burden_amenable")
  data$gbd_id <- data$burden_amenable <- data$gbd_category <- 
    data$GBD.Disease.Category <- data$Burden.Age.Group <- data$GBD.Disease.Category.Description  <- NULL
  data <- unique(data)
  rownames(data) <- NULL
  
## add (0 years) to Immediate
  data$'Average Benefit Timing'[data$'Average Benefit Timing'=="Immediate"] <- "Immediate (0 years)"
  
## rename
  data$'Average Benefit Timing'[data$'Average Benefit Timing'=="Immediate (0 years)"] <- "Immediate (~0 years)"
  data$'Average Benefit Timing'[data$'Average Benefit Timing'=="5 years"] <- "Short term (~5 years)"
  data$'Average Benefit Timing'[data$'Average Benefit Timing'=="10 years"] <- "Medium term (~10 years)"
  data$'Average Benefit Timing'[data$'Average Benefit Timing'=="20 years"] <- "Long term (~20 years)"

## sort by timing, then intervention
  data$sort <- NA
  data$sort[data$'Average Benefit Timing'=="Immediate (~0 years)"] <- 1
  data$sort[data$'Average Benefit Timing'=="Short term (~5 years)"] <- 2
  data$sort[data$'Average Benefit Timing'=="Medium term (~10 years)"] <- 3
  data$sort[data$'Average Benefit Timing'=="Long term (~20 years)"] <- 4
  data <- data[order(data$sort,data$`Intervention #`),]
  data$sort <- NULL
  
## outsheet to table to csv
  write.table(data,"./05_tables/TABLE_APPENDIX_3_Time_Lags.csv",sep=",",row.names=F)
  
  
  