## Author:  Kate Lofgren (klofgren@g.harvard.edu)
## Date:    7/20/2019
## Purpose: Table of Temporal Mappings between interventions

## bring in parameters
  rm(list=ls())
  set.seed(02139)
  date <- Sys.Date()
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")

## load libraries
  library(foreign)
  library(gdata)
  library(kableExtra)
  library(knitr)

## bring in relevant data
  data <- read.xls(file,sheet="Temporal Spacing",stringsAsFactors=F)
  names(data) <- c("GBD Category",
                   "GBD Category Description",
                   "Independent Int. #",
                   "Independent Interventions",
                   "Dependent Int. #",
                   "Dependent Interventions")
  
## get rid of GBD Category
  data$'GBD Category' <- NULL
  
# save the table
  write.table(data,"./05_tables/TABLE_APPENDIX_4_Temporal.csv",sep=",",row.names=F)
  
  