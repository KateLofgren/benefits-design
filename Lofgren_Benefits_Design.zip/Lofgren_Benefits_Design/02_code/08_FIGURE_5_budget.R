## Author:  Kate Lofgren (kate.lofgren@g.harvard.edu)
## Date:    8/25/2018
## Purpose: Graph results

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(ggplot2)
  library(gridExtra)
  library(gdata)
  library(ggExtra)
  library(viridis)
  library(RColorBrewer)
  library(forcats)
  
## set seed
  set.seed(02139)
  options(scipen = 999)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")
  
## bring in data
  data <- read.table("./03_output_data/05_optimized_interventions_single_obj.csv", sep=",", header=T, stringsAsFactors=F)
  package <- read.table("./03_output_data/05_optimized_package_counts_single_obj.csv", sep=",", header=T, stringsAsFactors=F)
  
## merge in intervention names
  info <- read.xls(file,sheet="Interventions - Basics")
  info$X <- NULL
  names(info) <- c("WHO","int_n","int_des","int_des_short","int_target")
  info <- info[info$int_n!=3.1 & info$int_n!=3.2 & info$int_n!=3.3 & 
                 info$int_n!=4.1 & info$int_n!=4.2,] # don't want maternal care signal functions
  data <- merge(info,data,by=c("int_n"),all.y=T)
  
## colors
  colors <- viridis(n=10)
  colors.1 <- brewer.pal(n=10,"BrBG")
  colors.2 <- inferno(n=10)
  
## figure out what happens between 60 and 65 million when MAX Deaths
  temp <- data[data$objective=="delta.deaths" & data$budget %in% c(60000000,65000000),]
  temp2 <- aggregate(fund ~ int_n,FUN=sum,data=temp)
  int.list <- temp2[temp2$fund==1,]
  temp3 <- temp[temp$int_n %in% c(int.list$int_n),]
  temp3 <- temp3[order(temp3$int_n,temp3$budget),]
  ## SBA and Mat. BP screen/treat dropped, surgery added
  
############################################################## 
## graph of deaths / CHE averted across budgets
##############################################################  
  package$budget                <- package$budget/1000000
  x <- 1000
  package$package.deaths        <- package$package.deaths/x
  package$package.che.10        <- package$package.che.10/x
  package$package.deaths.LB        <- package$package.deaths.LB/x
  package$package.che.10.LB        <- package$package.che.10.LB/x
  package$package.deaths.UB        <- package$package.deaths.UB/x
  package$package.che.10.UB        <- package$package.che.10.UB/x
  package$package.che.25        <- package$package.che.25/x
  package$package.che.10.direct <- package$package.che.10.direct/x
  package$package.che.25.direct <- package$package.che.25.direct/x
  package$package.deaths.npv    <- package$package.deaths.npv/x
  package$package.che.10.npv    <- package$package.che.10.npv/x
  package$package.che.25.npv    <- package$package.che.25.npv/x
  
  top <- 80
  death.pack <- package[package$objective=="delta.deaths" & 
                          package$budget %in% c(1,seq(0,top,5)),]
  che.10.pack <- package[package$objective=="che.10" & 
                           package$budget %in% c(1,seq(0,top,5)),]
  che.25.pack <- package[package$objective=="che.25" & 
                           package$budget %in% c(1,seq(0,top,5)),]
  che.10.dir.pack <- package[package$objective=="che.10.direct" & 
                           package$budget %in% c(1,seq(0,top,5)),]
  che.25.dir.pack <- package[package$objective=="che.25.direct" & 
                           package$budget %in% c(1,seq(0,top,5)),]
  death.npv.pack <- package[package$objective=="delta.deaths.npv" & 
                          package$budget %in% c(1,seq(0,top,5)),]
  che.10.npv.pack <- package[package$objective=="che.10.npv" & 
                           package$budget %in% c(1,seq(0,top,5)),]
  che.25.npv.pack <- package[package$objective=="che.25.npv" & 
                           package$budget %in% c(1,seq(0,top,5)),]
  
  
  death.LB.pack <- package[package$objective=="delta.deaths.LB" & 
                          package$budget %in% c(1,seq(0,top,5)),]
  che.10.LB.pack <- package[package$objective=="che.10.LB" & 
                           package$budget %in% c(1,seq(0,top,5)),]
  death.UB.pack <- package[package$objective=="delta.deaths.UB" & 
                             package$budget %in% c(1,seq(0,top,5)),]
  che.10.UB.pack <- package[package$objective=="che.10.UB" & 
                              package$budget %in% c(1,seq(0,top,5)),]
  ## figure out y-axis max
  max <- max(package$package.deaths,package$package.che.10,
             package$package.deaths.UB,package$package.che.10.UB)
  
  max.d <- max(package$package.deaths,
             package$package.deaths.UB)
  max.c <- max(package$package.che.10,
               package$package.che.10.UB)

################################################################
## Panel Version across budgets and across single objectives ###
## delta.deaths, che.10, che.25                              ###
################################################################
pdf("./04_figures/FIGURE_5.pdf",height=8,width=11) 
  
  par(xpd=FALSE,mar = c(6.5, 6.5, 4.5, 1), mgp = c(4.75, 1, 0),mfrow=c(2,2))
  
## plot 1 - deaths when deaths max
  plot(death.pack$budget,death.pack$package.deaths,ylim=c(0,max.d),
       pch="",col="black",cex=2,xlab="Budget (millions USD)",ylab="Cases Averted (1000s)",
       cex.lab=1.75,cex.axis=1.75,lwd=4,las=1,main="A: Maximize \nPopulation Health\nDeaths Averted",cex.main=1.3,family="serif")
  
  # plot lines when optimized on deaths averted 
  # deaths averted
  # UNCERT
  points(death.pack$budget,death.pack$package.deaths.LB,pch=19,col="gray50")
  lines(death.pack$budget,death.pack$package.deaths.LB,lty=1,col="gray50")
  points(death.pack$budget,death.pack$package.deaths.UB,pch=19,col="gray50")
  lines(death.pack$budget,death.pack$package.deaths.UB,lty=1,col="gray50")
  
  points(death.pack$budget,
         death.pack$package.deaths,pch=19,cex=1.5,col=colors[1])
  lines(death.pack$budget,death.pack$package.deaths,lwd=3,col=colors[1])
  
  # add annotations
  par(xpd=TRUE)
  text(x=74,y=5, labels="Deaths", cex=1.25, col=colors[1],family="serif")
  text(x=72,y=7.4, labels="Optimistic", cex=1.25, col="gray20",family="serif")
  text(x=72,y=2.5, labels="Pessimistic", cex=1.25, col="gray20",family="serif")
  
## plot 2 - deaths when CHE max
  plot(death.pack$budget,death.pack$package.deaths,ylim=c(0,max.d),
       pch="",col="black",cex=2,xlab="Budget (millions USD)",ylab="",
       cex.lab=1.75,cex.axis=1.75,lwd=4,las=1,
       main="B: Maximize \nFinancial Risk Protection\nDeaths Averted",cex.main=1.3,family="serif")
  
  # plot lines when optimized on CHE 10% averted 
  # deaths averted
  # UNCERT
  points(che.10.pack$budget,che.10.pack$package.deaths.LB,pch=19,col="gray50")
  lines(che.10.pack$budget,che.10.pack$package.deaths.LB,lty=1,col="gray50")
  points(che.10.pack$budget,che.10.pack$package.deaths.UB,pch=19,col="gray50")
  lines(che.10.pack$budget,che.10.pack$package.deaths.UB,lty=1,col="gray50")
  
  points(che.10.pack$budget,
         che.10.pack$package.deaths,pch=19,cex=1.5,col=colors[1])
  lines(che.10.pack$budget,che.10.pack$package.deaths,lwd=3,col=colors[1])
  
  # add annotations
  par(xpd=TRUE)
  text(x=76,y=4, labels="Deaths", cex=1.25, col=colors[1],family="serif")
  
  
# plot 3 - CHE when deaths are maximized
  # CHE 10% averted
  # UNCERT
  plot(death.pack$budget,death.pack$package.deaths,ylim=c(0,max.c),
       pch="",col="black",cex=2,xlab="Budget (millions USD)",ylab="Cases Averted (1000s)",
       cex.lab=1.75,cex.axis=1.75,lwd=4,las=1,main="C: Maximize \nPopulation Health\nCHE 10% Averted",cex.main=1.3,family="serif")
  points(death.pack$budget,death.pack$package.che.10.LB,pch=19,col="gray50")
  lines(death.pack$budget,death.pack$package.che.10.LB,lty=1,col="gray50")
  points(death.pack$budget,death.pack$package.che.10.UB,pch=19,col="gray50")
  lines(death.pack$budget,death.pack$package.che.10.UB,lty=1,col="gray50")
  
  # Dots
  points(death.pack$budget,
         death.pack$package.che.10,pch=19,cex=1.5,col=colors[4])
  lines(death.pack$budget,death.pack$package.che.10,lwd=3,col=colors[4])
  
  # add annotations
  par(xpd=TRUE)
  text(x=74,y=85, labels="CHE 10%", cex=1.25, col=colors[4],family="serif")
  text(x=30,y=350, labels="Basic surgical package added\nMat. BP screen/treat\nand SBA dropped", cex=1.25, col="black",family="serif")
  arrows(45, 300, 60, 300, length = 0.1, angle = 30, code = 2,
         col = par("fg"), lty = NULL, xpd = FALSE,lwd=2)
  
  
## plot 4 - CHE when CHE are maximized
  plot(death.pack$budget,death.pack$package.deaths,ylim=c(0,max.c),
       pch="",col="black",cex=2,xlab="Budget (millions USD)",ylab="",
       cex.lab=1.75,cex.axis=1.75,lwd=4,las=1,
       main="D: Maximize \nFinancial Risk Protection\nCHE 10% Averted",cex.main=1.3,family="serif")
  
  # CHE 10% averted
  # UNCERT
  points(che.10.pack$budget,che.10.pack$package.che.10.LB,pch=19,col="gray50")
  lines(che.10.pack$budget,che.10.pack$package.che.10.LB,lty=1,col="gray50")
  points(che.10.pack$budget,che.10.pack$package.che.10.UB,pch=19,col="gray50")
  lines(che.10.pack$budget,che.10.pack$package.che.10.UB,lty=1,col="gray50")
  
  points(che.10.pack$budget,
         che.10.pack$package.che.10,pch=19,cex=1.5,col=colors[4])
  lines(che.10.pack$budget,che.10.pack$package.che.10,lwd=3,col=colors[4])
  
  # add annotations
  par(xpd=TRUE)
  text(x=74,y=500, labels="CHE 10%", cex=1.25, col=colors[4],family="serif")

dev.off()     
  
  
