## Author:  Kate Lofgren
## Date:    8/3/2019
## Purpose: Graph full feasability space for one budget scenario

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(lpSolve)
  library(reshape2)
  library(viridis)

## set seed
  set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")
  
## bring in the data
  pc <- read.table("./03_output_data/05_optimized_package_counts_full_frontier.csv",sep=",",header=T,stringsAsFactors=F)
  
## keep budget for first graph
  pc <- pc[pc$budget==40000000,] 
  
## get rid of the zeros -- these constraints (k) where too large
  pc <- pc[pc$package.deaths!=0 | pc$package.che.10!=0,]
  pc <- pc[,c("objective","package.deaths","package.che.10","constraint")]
  pc <- unique(pc)  
  
## save a file with the single objectives for plot
  d.max <- max(pc$package.deaths[pc$objective=="delta.deaths"]) 
  che.max <- max(pc$package.che.10[pc$objective=="che.10"])
  single <- pc[(pc$package.deaths>=d.max | pc$package.che.10 >=che.max) & pc$constraint=="<=",]
  
## create a cohesive set of points to plot for the pareto frontier that combine deaths and CHE info
  front <- pc[pc$constraint==">=",]
  front <- front[order(front$package.deaths),]
  front <- front[c("package.deaths","package.che.10")]
  front <- unique(front)    
  

###################################################################################
####### plot the feasable space and the pareto frontier / optimal solutions #######
###################################################################################
  
# create a color palette for the plot
  colors <- viridis(10)
  colors2 <- plasma(10)
  
# start plot
pdf("./04_figures/FIGURE_3.pdf",height=8,width=11)
  
  # plot code
  par(mar=c(6.5,6.5,2.5,1),mfrow=c(1,1))
  plot(pc$package.che.10[pc$objective=="delta.deaths"],pc$package.deaths[pc$objective=="delta.deaths"],
       pch="",ylim=c(0,max(pc$package.deaths)+1500),xlim=c(0,max(pc$package.che.10)+100000),
       ylab="",
       xlab="Catastrophic Health Expenditures Averted",
       las=1,cex.lab=2,cex.axis=1.5,family="serif")
  
  ## add in y axis label
  title(ylab = "Deaths Averted", cex.lab = 2,
        line = 4.5,family="serif")
  
  # lines for feasible bounds
  lines(pc$package.che.10[pc$objective=="delta.deaths" & pc$constraint=="<="],
        pc$package.deaths[pc$objective=="delta.deaths"& pc$constraint=="<="],lwd=3,col="gray35")
  lines(pc$package.che.10[pc$objective=="che.10"& pc$constraint=="<="],
        pc$package.deaths[pc$objective=="che.10"& pc$constraint=="<="],lwd=3,col="gray35")
  
  # points and lines for the frontier
  points(front$package.che.10,
         front$package.deaths,pch=19,cex=2,col=colors[5])
  lines(front$package.che.10,
         front$package.deaths,lwd=3,col=colors[5])
  
  ## optimal solutions for single objectives
    ## Deaths
    points(single$package.che.10[single$objective=="delta.deaths"],
           single$package.deaths[single$objective=="delta.deaths"],pch=19,cex=4,col=colors2[7])
    text(single$package.che.10[single$objective=="delta.deaths"]+2500,
         single$package.deaths[single$objective=="delta.deaths"]+1000,
         "Optimal solution:\nMAX Population Health\nas single objective",cex=1.5,family="serif")
    
    ## CHE 10%
    points(single$package.che.10[single$objective=="che.10"],
           single$package.deaths[single$objective=="che.10"],pch=19,cex=4,col=colors2[7])
    text(single$package.che.10[single$objective=="che.10"]-150000,
         single$package.deaths[single$objective=="che.10"]+300,
         "Optimal solution:\nMAX Financial Risk Protection\nas single objective",cex=1.5,family="serif")
  
  # text for selected points on the frontier
    # che as a single objective result
    text(front$package.che.10[front$package.che.10==426539 & front$package.deaths<=1237]+500, ## need to offset
         front$package.deaths[front$package.che.10==426539 & front$package.deaths<=1237],
         paste0("(",round(front$package.che.10[front$package.che.10==426539 & front$package.deaths<=1237]),", ",
                round(front$package.deaths[front$package.che.10==426539 & front$package.deaths<=1237]),")"),
         pos=4,offset=0.7,cex=1.5,col="black",family="serif")
    
    # possible solutions along the frontier
    text(front$package.che.10[front$package.che.10==423212 & front$package.deaths>=2911],
         front$package.deaths[front$package.che.10==423212 & front$package.deaths>=2911],
         paste0("(",round(front$package.che.10[front$package.che.10==423212 & front$package.deaths>=2911]),", ",
                round(front$package.deaths[front$package.che.10==423212 & front$package.deaths>=2911]),")"),
         pos=4,offset=0.7,cex=1.5,family="serif",col="black")
    
    # possible solutions along the frontier
    text(front$package.che.10[front$package.che.10==335845 & front$package.deaths>=4878],
         front$package.deaths[front$package.che.10==335845 & front$package.deaths>=4878],
         paste0("(",round(front$package.che.10[front$package.che.10==335845 & front$package.deaths>=4878]),", ",
                round(front$package.deaths[front$package.che.10==335845 & front$package.deaths>=4878]),")"),
         pos=4,offset=0.7,cex=1.5,family="serif",col="black")
    
    
    # possible solutions along the frontier
    text(front$package.che.10[front$package.che.10==202123 & front$package.deaths>=5173],
         front$package.deaths[front$package.che.10==202123 & front$package.deaths>=5173],
         paste0("(",round(front$package.che.10[front$package.che.10==202123 & front$package.deaths>=5173]),", ",
                round(front$package.deaths[front$package.che.10==202123 & front$package.deaths>=5173]),")"),
         pos=4,offset=0.7,cex=1.5,family="serif",col="black")
    
    # deaths as single objective result
    text(front$package.che.10[front$package.che.10==177170 &front$package.deaths>=5174]+1600,
         front$package.deaths[front$package.che.10==177170 & front$package.deaths>=5174]-300,
         paste0("(",round(front$package.che.10[front$package.che.10==177170 & front$package.deaths>=5174]),", ",
                round(front$package.deaths[front$package.che.10==177170 & front$package.deaths>=5174]),")"),
         pos=1,offset=0.7,cex=1.5,col="black",family="serif")
    
    ## add arrows
    arrows(350000, 1236, 426000, 1236, length = 0.1, angle = 30, code = 2,
           col = par("fg"), lty = NULL, xpd = FALSE,lwd=2)
    arrows(177170, 5600, 177170, 5150, length = 0.1, angle = 30, code = 2,
           col = par("fg"), lty = NULL, xpd = FALSE,lwd=2)
# stop plot
dev.off()


