## Author:  Kate Lofgren
## Date:    8/3/2019
## Purpose: Appendix Table: Unit and OOP Cost - for screen/treat interventions

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(lpSolve)
  library(reshape2)
  library(viridis)
  library(gdata)

## set seed
  set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")
  
## percent of screened, treated
  p.screen <- read.xls(file,sheet="Interventions - Screening",stringsAsFactors=F)
  p.screen <- p.screen[,1:4]
  names(p.screen) <-  c("int_n","int_des","p.treat","sources")

## unit costs
  uc.screen <- read.xls(file,sheet="Interventions - UC Screen",stringsAsFactors=F)
  uc.screen <- uc.screen[,c("Intervention..","Final.Screen","Final.Treat")]
  names(uc.screen) <- c("int_n","screen.cost","treat.cost")

## merge together
  data <- merge(p.screen,uc.screen,by=c("int_n"),all=T)
  
## need treatment cost for TB and maternal BP
  u.cost <- read.xls(file,sheet="Interventions - Unit Cost",stringsAsFactors=F)
  u.cost <- u.cost[,c("Intervention..","Intervention.Unit.Cost..2016.USD.","Source","Details")]
  names(u.cost)[1:2] <- c("int_n","unit.cost")
  u.cost <- u.cost[u.cost$int_n %in% c(1,12),]
  names(u.cost)[1:3] <- c("int_n","treat.cost.2","sources.2")
  u.cost$Details <- NULL
  
  # merge with main data
  data <- merge(data,u.cost,by=c("int_n"),all=T)
  data$sources[data$int_n %in% c(1,12)] <- paste0(data$sources[data$int_n %in% c(1,12)],"; ",data$sources.2[data$int_n %in% c(1,12)])
  data$treat.cost[data$int_n %in% c(1,12)] <- data$treat.cost.2[data$int_n %in% c(1,12)]
  data$treat.cost.2 <- data$sources.2 <- NULL

  data$p.treat <- data$p.treat*100
  
## create better names for appendix table
  data <- data[,c("int_n","int_des","p.treat","screen.cost","treat.cost","sources")]
  names(data)[1:6] <- c("Intervention #",
                        "Intervention",
                        "Prob. Screen Patient Treated (%)",
                        "Screen Cost (2016 USD)",
                        "Treatment Cost (2016 USD)","Sources")

## outsheet to table to csv
  write.table(data,"./05_tables/TABLE_APPENDIX_6_Costs_SCREEN-TREAT.csv",sep=",",row.names=F)


