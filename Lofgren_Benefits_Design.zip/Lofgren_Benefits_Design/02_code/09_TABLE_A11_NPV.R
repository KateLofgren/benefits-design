## Author:  Kate Lofgren (kate.lofgren@g.harvard.edu)
## Date:    9/15/2018
## Purpose: Appendix Table 10

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(ggplot2)
  library(gridExtra)
  library(gdata)
  library(ggExtra)
  library(viridis)
  library(RColorBrewer)
  library(forcats)

## set seed
  set.seed(02139)
  options(scipen = 999)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")

## bring in intervention names
  info <- read.xls(file,sheet="Interventions - Basics")
  info$X <- NULL
  names(info) <- c("WHO","int_n","int_des","int_des_short","int_target")
  info <- info[info$int_n!=3.1 & info$int_n!=3.2 & info$int_n!=3.3 & 
                 info$int_n!=4.1 & info$int_n!=4.2,] # don't want maternal care signal functions

# bring in data
  temp <- read.table("./03_output_data/04_combined_decision_vars.csv",sep=",",header=T,stringsAsFactors=F)
  temp <- temp[temp$pop_burden_uncert=="MEAN" & temp$int_eff_uncert=="MEAN",]
  temp <- temp[,c("int_des","delta.deaths","che.10","delta.deaths.npv","che.10.npv")]
  temp <- unique(temp)

## merge with short int_des names
  temp <- merge(temp,info,by=c("int_des"),all.x=T)
  temp <- temp[,c("int_des_short","delta.deaths","che.10","delta.deaths.npv","che.10.npv")]

## calculate the difference between the interventions
  temp$deaths.diff <- temp$delta.deaths - temp$delta.deaths.npv
  temp$che.diff <- temp$che.10 - temp$che.10.npv

## only keep interventions with a difference
  temp <- temp[temp$deaths.diff !=0 | temp$che.diff != 0,]
  temp <- temp[,c("int_des_short","deaths.diff","che.diff")]

## write out the results
  write.table(temp,"./05_tables/TABLE_APPENDIX_11_NPV.csv",sep=",",row.names=F)

