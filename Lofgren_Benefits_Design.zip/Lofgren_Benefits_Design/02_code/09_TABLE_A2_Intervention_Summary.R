## Author:  Kate Lofgren
## Date:    8/3/2019
## Purpose: Appendix Table: Intervention Summary

## set up
rm(list=ls())
date <- Sys.Date()

## libraries
library(foreign)
library(dplyr)
library(lpSolve)
library(reshape2)
library(viridis)
library(gdata)

## set seed
set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")

## Intervention Main Info
  data <- read.xls(file,sheet="Interventions - Basics")
  data$X <- NULL
  names(data) <- c("WHO","int_n","int_des","int_des_short","int_target")

## bring in the data on intervention targets
  temp <- read.xls(file,sheet="Target Pop",stringsAsFactors=F)
  temp$X <- temp$X.1 <- temp$X.2 <- temp$X.3 <- NULL
  names(temp) <- c("int_n","int_des","gbd_n",
                   "target_type","target_pop",
                   "target_age","target_sex")
  temp <- temp[,c("int_n","target_age","target_sex")]
  temp <- unique(temp)
  
## merge files
  data <- merge(data,temp,by=c("int_n"),all=T)
  data <- data[,c("WHO","int_n","int_des","int_des_short","target_age","target_sex")]
  
## fix varaibles
  data$target_sex[data$target_sex=="females"] <- "Females"
  data$target_sex[data$target_sex=="males"] <- "Males"
  data$target_age[data$target_age=="births"] <- "Births"
  data$target_age[data$target_age=="under-5"] <- "0-4"

## get rid of extra lines
  data <- data[!is.na(data$target_age),]  
  
## create better names for appendix table
  names(data) <- c("WHO index category",
                   "",
                   "Intervention",
                   "Short name",
                   "Target Age group (years)",
                   "Target Sex")

  
## outsheet to table to csv
  write.table(data,"./05_tables/TABLE_APPENDIX_2_Intervention_Summary.csv",sep=",",row.names=F)



