## Author:  Kate Lofgren
## Date:    8/3/2019
## Purpose: Appendix Table: Tx. Effect Estimate Sources

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(lpSolve)
  library(reshape2)
  library(viridis)
  library(gdata)
  library(ggplot2)
  library(RColorBrewer)

## set seed
  set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")

## bring in the data
  data <- read.xls(file,sheet="Interventions - Efficacy",stringsAsFactors=F)
  data <- data[,c("Intervention..","Intervention","GBD.Disease.Category.Description",
                "Final","Effect.Target","LB.Final","UB.Final","Source","Details")]
  names(data) <- c("Intervention #",
                   "Intervention",
                   "Disease target",
                   "Estimate",
                   "Effect target","LB","UB","Source","Details")
  data <- data[,c("Intervention #","Intervention","Disease target",
                  "Effect target","Estimate","LB","UB","Source","Details")]

## make sure the estimates are rounded to 2 sigfigs
  data$Estimate <- round(data$Estimate,2)
  data$LB <- round(data$LB,2)
  data$UB <- round(data$UB,2)
  
## fix target caps
  data$'Effect target'[data$'Effect target'=="mortality"] <- "Mortality"
  data$'Effect target'[data$'Effect target'=="incidence"] <- "Incidence"
  
## outsheet to table to csv
  write.table(data,"./05_tables/TABLE_APPENDIX_9_Tx_Effects.csv",sep=",",row.names=F)
  

  
  
  