## Author:  Kate Lofgren
## Date:    8/3/2019
## Purpose: Appendix Table: Baseline Coverage

## set up
  rm(list=ls())
  date <- Sys.Date()

## libraries
  library(foreign)
  library(dplyr)
  library(lpSolve)
  library(reshape2)
  library(viridis)
  library(gdata)

## set seed
  set.seed(02139)

## set directory, bring in universal parameters
  setwd("/Users/katherinelofgren/Desktop/Lofgren_Benefits_Design/")
  source("./02_code/00_universal_parameters.R")

## bring in the data
  data <- read.xls(file,sheet="Interventions - Coverage",stringsAsFactors=F)
  data <- data[,2:7]
  names(data) <- c("int_n","int_des","who_cov","baseline_cov","source","details")
  data$baseline_cov <- data$baseline_cov*100

  data <- data[,c("int_n","int_des","baseline_cov","source","details")]
  names(data) <- c("Intervention #",
                   "Intervention",
                   "Baseline Coverage",
                   "Source",
                   "Details")
  
## round coverage to 2 sigfigs
  data$'Baseline Coverage' <- round(data$'Baseline Coverage',2)

## outsheet to table to csv
  write.table(data,"./05_tables/TABLE_APPENDIX_7_Baseline_Coverage.csv",sep=",",row.names=F)
